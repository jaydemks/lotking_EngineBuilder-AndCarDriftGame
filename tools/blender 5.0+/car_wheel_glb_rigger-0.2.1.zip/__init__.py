bl_info = {
    "name": "Car Wheel GLB Rigger",
    "author": "CodesAndTips",
    "version": (0, 2, 1),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar (N) > Car Rig",
    "description": "Quick car body and wheel rig setup for GLB export workflows in three.js.",
    "category": "Object",
}

import bpy
from pathlib import Path
from bpy.props import PointerProperty
from bpy.types import AddonPreferences, Panel, Operator, PropertyGroup


ADDON_VERSION = "0.2.1"


def addon_module_name():
    return __package__ or __name__


def addon_install_folder():
    return str(Path(__file__).resolve().parent)


class CarRigProps(PropertyGroup):
    body: PointerProperty(name="Body", type=bpy.types.Object)
    wheel_fl: PointerProperty(name="Front Left Wheel", type=bpy.types.Object)
    wheel_fr: PointerProperty(name="Front Right Wheel", type=bpy.types.Object)
    wheel_rl: PointerProperty(name="Rear Left Wheel", type=bpy.types.Object)
    wheel_rr: PointerProperty(name="Rear Right Wheel", type=bpy.types.Object)
    disc_fl: PointerProperty(name="Front Left Brake Disc", type=bpy.types.Object)
    disc_fr: PointerProperty(name="Front Right Brake Disc", type=bpy.types.Object)
    disc_rl: PointerProperty(name="Rear Left Brake Disc", type=bpy.types.Object)
    disc_rr: PointerProperty(name="Rear Right Brake Disc", type=bpy.types.Object)
    caliper_fl: PointerProperty(name="Front Left Brake Caliper", type=bpy.types.Object)
    caliper_fr: PointerProperty(name="Front Right Brake Caliper", type=bpy.types.Object)
    caliper_rl: PointerProperty(name="Rear Left Brake Caliper", type=bpy.types.Object)
    caliper_rr: PointerProperty(name="Rear Right Brake Caliper", type=bpy.types.Object)


class CARRIG_OT_assign(Operator):
    """Assign the active selected object to this rig slot."""

    bl_idname = "carrig.assign"
    bl_label = "Assign Selection"
    bl_options = {"REGISTER", "UNDO"}

    slot: bpy.props.StringProperty()

    def execute(self, context):
        obj = context.active_object
        if obj is None:
            self.report({"WARNING"}, "No active object selected")
            return {"CANCELLED"}

        setattr(context.scene.car_rig, self.slot, obj)
        self.report({"INFO"}, f"Assigned '{obj.name}'")
        return {"FINISHED"}


def set_origin_to_center(obj, context):
    context.view_layer.objects.active = obj
    for selected in context.selected_objects:
        selected.select_set(False)
    obj.select_set(True)
    bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")


def parent_keep_transform(obj, parent):
    world_matrix = obj.matrix_world.copy()
    obj.parent = parent
    obj.matrix_parent_inverse = parent.matrix_world.inverted()
    obj.matrix_world = world_matrix


def make_empty(name, location, collection, parent=None, size=0.15):
    empty = bpy.data.objects.new(name, None)
    empty.empty_display_type = "PLAIN_AXES"
    empty.empty_display_size = size
    collection.objects.link(empty)
    empty.location = location
    if parent:
        parent_keep_transform(empty, parent)
    return empty


class CARRIG_OT_build(Operator):
    """Build a GLB-friendly hierarchy with steering and spin pivots."""

    bl_idname = "carrig.build"
    bl_label = "Build GLB Hierarchy"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.car_rig

        if not props.body:
            self.report({"ERROR"}, "Assign the body object first")
            return {"CANCELLED"}

        corners = {
            "FL": {
                "wheel": props.wheel_fl,
                "disc": props.disc_fl,
                "caliper": props.caliper_fl,
                "steers": True,
            },
            "FR": {
                "wheel": props.wheel_fr,
                "disc": props.disc_fr,
                "caliper": props.caliper_fr,
                "steers": True,
            },
            "RL": {
                "wheel": props.wheel_rl,
                "disc": props.disc_rl,
                "caliper": props.caliper_rl,
                "steers": False,
            },
            "RR": {
                "wheel": props.wheel_rr,
                "disc": props.disc_rr,
                "caliper": props.caliper_rr,
                "steers": False,
            },
        }

        for key, corner in corners.items():
            if corner["wheel"] is None:
                self.report({"ERROR"}, f"Wheel {key} is not assigned")
                return {"CANCELLED"}

        root = make_empty("Car", (0, 0, 0), context.collection, size=1.0)

        props.body.name = "Body"
        parent_keep_transform(props.body, root)

        for key, corner in corners.items():
            wheel = corner["wheel"]
            disc = corner["disc"]
            caliper = corner["caliper"]
            steers = corner["steers"]

            set_origin_to_center(wheel, context)
            world_loc = wheel.matrix_world.translation.copy()
            steer_parent = root

            if steers:
                steer_parent = make_empty(
                    f"Wheel_{key}_steer",
                    world_loc,
                    context.collection,
                    parent=root,
                )

            spin = make_empty(
                f"Wheel_{key}_spin",
                world_loc,
                context.collection,
                parent=steer_parent,
            )

            wheel.name = f"Wheel_{key}_mesh"
            parent_keep_transform(wheel, spin)

            if disc:
                set_origin_to_center(disc, context)
                disc.name = f"BrakeDisc_{key}_mesh"
                parent_keep_transform(disc, spin)

            if caliper:
                caliper.name = f"BrakeCaliper_{key}_mesh"
                parent_keep_transform(caliper, steer_parent)

        for selected in context.selected_objects:
            selected.select_set(False)
        root.select_set(True)
        context.view_layer.objects.active = root

        self.report({"INFO"}, "Hierarchy created. Ready for GLB export.")
        return {"FINISHED"}


class CARRIG_OT_export(Operator):
    """Export the scene as GLB with settings suitable for three.js."""

    bl_idname = "carrig.export"
    bl_label = "Export GLB"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        if not self.filepath.lower().endswith(".glb"):
            self.filepath += ".glb"

        bpy.ops.export_scene.gltf(
            filepath=self.filepath,
            export_format="GLB",
            export_yup=True,
            export_apply=True,
            use_selection=False,
        )

        self.report({"INFO"}, f"Exported: {self.filepath}")
        return {"FINISHED"}

    def invoke(self, context, event):
        self.filepath = "car.glb"
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class CARRIG_OT_open_install_folder(Operator):
    """Open the folder where this add-on is installed."""

    bl_idname = "carrig.open_install_folder"
    bl_label = "Open Install Folder"

    def execute(self, context):
        bpy.ops.wm.path_open(filepath=addon_install_folder())
        return {"FINISHED"}


class CARRIG_OT_uninstall_self(Operator):
    """Disable and remove this add-on through Blender preferences."""

    bl_idname = "carrig.uninstall_self"
    bl_label = "Uninstall This Add-on"

    def execute(self, context):
        module_name = addon_module_name()

        try:
            bpy.ops.preferences.addon_disable(module=module_name)
            bpy.ops.preferences.addon_remove(module=module_name)
        except Exception as exc:
            self.report({"ERROR"}, f"Could not uninstall automatically: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, "Add-on uninstall requested")
        return {"FINISHED"}


class CarRigPreferences(AddonPreferences):
    bl_idname = addon_module_name()

    def draw(self, context):
        layout = self.layout
        layout.label(text=f"Version {ADDON_VERSION}")
        layout.label(text=f"Installed in: {addon_install_folder()}")

        row = layout.row(align=True)
        row.operator("carrig.uninstall_self", text="Uninstall This Add-on")
        row.operator("carrig.open_install_folder", text="Open Install Folder")


class CARRIG_PT_panel(Panel):
    bl_label = "Car Wheel Rigger"
    bl_idname = "CARRIG_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Car Rig"

    def draw(self, context):
        layout = self.layout
        props = context.scene.car_rig

        def slot_row(parent, label, prop_name):
            row = parent.row(align=True)
            row.prop(props, prop_name, text=label)
            op = row.operator("carrig.assign", text="Use Selected")
            op.slot = prop_name

        def corner_box(parent, title, wheel_prop, disc_prop, caliper_prop):
            box = parent.box()
            box.label(text=title)
            slot_row(box, "Wheel", wheel_prop)
            slot_row(box, "Disc", disc_prop)
            slot_row(box, "Caliper", caliper_prop)

        col = layout.column()
        col.label(text=f"Version {ADDON_VERSION}", icon="PLUGIN")
        col.separator()
        slot_row(col, "Body", "body")

        col.separator()
        col.label(text="Front corners steer:")
        corner_box(col, "Front Left", "wheel_fl", "disc_fl", "caliper_fl")
        corner_box(col, "Front Right", "wheel_fr", "disc_fr", "caliper_fr")

        col.separator()
        col.label(text="Rear corners:")
        corner_box(col, "Rear Left", "wheel_rl", "disc_rl", "caliper_rl")
        corner_box(col, "Rear Right", "wheel_rr", "disc_rr", "caliper_rr")

        layout.separator()
        layout.operator("carrig.build", text="Build GLB Hierarchy")
        layout.operator("carrig.export", text="Export GLB")

        layout.separator()
        box = layout.box()
        box.label(text="Generated hierarchy:")
        box.label(text="Car / Body")
        box.label(text="Wheel_FL_steer > Wheel_FL_spin")
        box.label(text="spin: wheel + disc")
        box.label(text="steer/root: caliper")


classes = (
    CarRigProps,
    CARRIG_OT_assign,
    CARRIG_OT_build,
    CARRIG_OT_export,
    CARRIG_OT_open_install_folder,
    CARRIG_OT_uninstall_self,
    CarRigPreferences,
    CARRIG_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.car_rig = PointerProperty(type=CarRigProps)


def unregister():
    if hasattr(bpy.types.Scene, "car_rig"):
        del bpy.types.Scene.car_rig
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
