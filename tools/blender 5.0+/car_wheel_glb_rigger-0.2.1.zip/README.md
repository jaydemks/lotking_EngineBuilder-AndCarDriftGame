# Car Wheel GLB Rigger

Version: `0.2.1`

Blender add-on for quickly preparing a car body, wheels, brake discs, and brake calipers for GLB export workflows, especially for three.js.

## Install

Install the generated ZIP from Blender. Release ZIP files are stored in `exports/`.

1. Open Blender.
2. Go to `Edit > Preferences > Extensions`.
3. Choose `Install from Disk...`.
4. Select `exports/car_wheel_glb_rigger-0.2.1.zip`.
5. Enable `Car Wheel GLB Rigger`.

The panel appears in `View3D > Sidebar (N) > Car Rig`.

## Uninstall

Remove it from Blender like a regular extension:

1. Open `Edit > Preferences > Extensions`.
2. Search for `Car Wheel GLB Rigger`.
3. Open the add-on options menu.
4. Choose `Uninstall`.

If Blender does not show its own uninstall command, expand the add-on preferences and use `Uninstall This Add-on`. The fallback button `Open Install Folder` shows exactly where Blender installed the files.

## Generated hierarchy

```text
Car
+ Body
+ Wheel_FL_steer
  + Wheel_FL_spin
    + Wheel_FL_mesh
    + BrakeDisc_FL_mesh
  + BrakeCaliper_FL_mesh
+ Wheel_FR_steer
  + Wheel_FR_spin
    + Wheel_FR_mesh
    + BrakeDisc_FR_mesh
  + BrakeCaliper_FR_mesh
+ Wheel_RL_spin
  + Wheel_RL_mesh
  + BrakeDisc_RL_mesh
+ BrakeCaliper_RL_mesh
+ Wheel_RR_spin
  + Wheel_RR_mesh
  + BrakeDisc_RR_mesh
+ BrakeCaliper_RR_mesh
```

Front wheels get steering pivots. Wheels and brake discs are parented to spin nodes. Brake calipers do not spin: front calipers follow steering, rear calipers stay fixed under the car root.
